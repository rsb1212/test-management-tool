package com.testmgmt.config;

import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.TimeUnit;

/**
 * Application-level bean configuration.
 *
 * DSA / PERFORMANCE:
 * ─────────────────────────────────────────────────────────────────────────────
 * Caffeine in-process cache replaces repeated DB aggregation queries.
 * Each cache is tuned independently:
 *
 *   dashboard        — 60s TTL, 200 entries  (project-level, moderate churn)
 *   allDashboards    — 60s TTL, 10 entries   (one per "all projects" call)
 *   moduleBreakdown  — 120s TTL, 200 entries (changes less often than status counts)
 *   workload         — 30s TTL, 50 entries   (team workload refreshed often)
 *   teamProductivity — 60s TTL, 50 entries   (manager-facing analytics)
 *   search           — 30s TTL, 500 entries  (per unique query string)
 *
 * All caches use maximumSize to bound memory.
 * Caffeine uses a Window TinyLFU admission policy — near-optimal hit rate.
 */
@Configuration
@EnableCaching
@EnableScheduling
public class AppConfig {

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Bean
    public CacheManager cacheManager() {
        CaffeineCacheManager manager = new CaffeineCacheManager();

        // Per-cache configuration via individual beans would require CaffeineSpec;
        // use a sensible default and override the heaviest caches.
        manager.setCaffeine(Caffeine.newBuilder()
                .maximumSize(500)
                .expireAfterWrite(60, TimeUnit.SECONDS)
                .recordStats());   // enables /actuator/metrics/cache.* monitoring

        // Register all named caches used by @Cacheable
        manager.setCacheNames(java.util.List.of(
                "dashboard",
                "allDashboards",
                "moduleBreakdown",
                "workload",
                "teamProductivity",
                "search"
        ));

        return manager;
    }
}
